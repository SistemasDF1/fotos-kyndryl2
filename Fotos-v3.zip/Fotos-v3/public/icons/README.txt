Para generar los iconos PWA:

1. Abre generate-icons.html en tu navegador
2. Haz clic en "Generar Todos los Iconos"
3. Se descargarán automáticamente todos los tamaños necesarios

O usa cualquier herramienta online como:
- https://www.pwabuilder.com/imageGenerator
- https://favicon.io/favicon-generator/

Tamaños necesarios:
- 72x72, 96x96, 128x128, 144x144
- 152x152, 192x192, 384x384, 512x512